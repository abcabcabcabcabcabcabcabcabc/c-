﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace question2
{
    internal class Myclass
    {
    }
    private void SayHello()
    {
        Console.WriteLine("Hello, World!");
    }
}
