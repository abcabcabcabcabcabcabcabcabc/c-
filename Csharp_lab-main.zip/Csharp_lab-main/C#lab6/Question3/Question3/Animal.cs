﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question3
{
    internal class Animal
    {
    }
    public void AnimalMethod()
    {
        Console.Write("I am an animal ");
    }
}

}
