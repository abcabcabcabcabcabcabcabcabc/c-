﻿class Program
{
    static void Main(string[] args)
    {
        Dog dog = new Dog();
        dog.AnimalMethod();
        dog.DogMethod();

        Console.ReadLine();
    }
}