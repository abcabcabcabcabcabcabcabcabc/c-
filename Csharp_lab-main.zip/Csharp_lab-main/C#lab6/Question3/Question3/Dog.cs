﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Question3
{
    internal class Dog
    {
    }
    public void DogMethod()
    {
        Console.Write("I have four legs");
    }
}

}
